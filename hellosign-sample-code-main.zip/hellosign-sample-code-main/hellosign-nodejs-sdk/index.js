module.exports = require('./lib/hellosign.js');
